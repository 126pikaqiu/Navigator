package com.fudan.sw.dsa.project2.bean;

import java.util.ArrayList;
import java.util.Stack;

class Dijkstra {
    private double minutes;
    private void DIJKSTRA(ArrayList<Vertex> vertices, Vertex start, Vertex end){ //某个算法
        initialize_single_source(vertices,start);
        MinHeap minHeap = new MinHeap(vertices);
        while (!minHeap.isEmpty()){
            Vertex u = minHeap.extract_min();
            if(u == end ){   //找到了,结束
                minutes = u.getDistance();
                break;
            }
            for(Vertex vertex:u.getVertices()){
                relex(u,vertex,minHeap);
            }
        }
    }

    private void initialize_single_source(ArrayList<Vertex> graph, Vertex start){ //初始化所有点的距离
        for(Vertex vertex:graph){
            vertex.setDistance(Double.MAX_VALUE);
        }
        start.setDistance(0);
    }

    private void initialize_single_source1(ArrayList<Vertex> graph, Vertex start){ //初始化所有点的距离
        for(Vertex vertex:graph){
            vertex.setChangeTimes(15);
            vertex.clearAll();
        }
        start.setChangeTimes(0);
    }

    private void relex(Vertex preVertex, Vertex now,MinHeap minHeap){ //松弛一条边
        if(now.getDistance() > preVertex.getDistance() + preVertex.getEdge(now).getWeight()){
            now.setPreVertex(preVertex);
            now.setDistance(preVertex.getDistance() + preVertex.getEdge(now).getWeight());
            minHeap.update(now);
        }
    }

    private void relex1(Vertex preVertex, Vertex now,MinHeap1 minHeap){ //松弛一条边
        if(now.getChangeTimes() > preVertex.getChangeTimes() + preVertex.getChangeOrNot(now)){
            now.setPreVertices(preVertex,0);
            now.setChangeTimes(preVertex.getChangeTimes() + preVertex.getChangeOrNot(now));
            now.setToLines(preVertex.getEdge(now).getLine(),0);
            minHeap.update(now);
        }else if(now.getChangeTimes() == preVertex.getChangeTimes() + preVertex.getChangeOrNot(now)){
            now.setPreVertices(preVertex,1);
            now.setToLines(preVertex.getEdge(now).getLine(),1);
            if(now.getToLines().split(":").length >= 2 && !minHeap.contains(now))
                minHeap.insert(now);
        }
    }

    ArrayList<Vertex> getPath(ArrayList<Vertex> vertices1, Vertex start, Vertex end,int type){ //返回路径列表
        if(type == 0)
            return getPath1(vertices1,start,end);
        else{
            return getPath2(vertices1,start,end);
        }

    }

    private ArrayList<Vertex> getPath1(ArrayList<Vertex> vertices1, Vertex start, Vertex end){ //返回路径列表
        DIJKSTRA(vertices1,start,end);
        ArrayList<Vertex> path = new ArrayList<>();
        Stack<Vertex> vertices = new Stack<>();
        vertices.push(end);
        while (end != start && end.getPreVertex() != null){
            end = end.getPreVertex();
            vertices.push(end);
        }
        while (!vertices.empty()){
            path.add(vertices.pop());
        }
        return path;
    }

    private ArrayList<Vertex> getPath2(ArrayList<Vertex> vertices1, Vertex start, Vertex end){ //返回路径列表
        DIJKSTRA1(vertices1,start,end);
        Stack<Vertex> vertices = new Stack<>();
        int index = 0;
        String line = end.getPreVertex(index).getEdge(end).getLine();
        vertices.push(end);
        while(end != start){
            end = end.getPreVertex(index);
            vertices.push(end);
            if(end == start)
                break;
            index = end.linesIndexof(line);
            line = end.getEdge(end.getPreVertex(index)).getLine();
        }
        ArrayList<Vertex> path = new ArrayList<>();
        while (!vertices.empty()){
            path.add(vertices.pop());
        }

        minutes = 0;
        for(int i = 1; i < path.size(); i++){
            minutes += path.get(i).getEdge(start).getWeight();
            start = path.get(i);
        }
        return path;
    }

    double getMinutes(){
        return minutes;
    }

    private void DIJKSTRA1(ArrayList<Vertex> vertices, Vertex start, Vertex end){ //某个算法
        initialize_single_source1(vertices,start);
        MinHeap1 minHeap = new MinHeap1(vertices);
        while (!minHeap.isEmpty()){
            Vertex u = minHeap.extract_min();
            if( u == end){   //找到了共线站,结束
                return;
            }
            for(Vertex vertex:u.getVertices()){
                relex1(u,vertex,minHeap);
            }
        }
    }

}

