package com.fudan.sw.dsa.project2.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.fudan.sw.dsa.project2.bean.Address;
import com.fudan.sw.dsa.project2.bean.Navigator;
import com.fudan.sw.dsa.project2.bean.ReturnValue;
import com.fudan.sw.dsa.project2.constant.FileGetter;

/**
 * this class is what you need to complete
 * @author zjiehang
 *
 */
@Service
public class IndexService 
{
	//the subway graph
	private Navigator navigator = null;
	
	/**
	 * create the graph use file
	 */
	public void createGraphFromFile()
	{
		//如果图未初始化
		if(navigator==null)
		{
			FileGetter fileGetter= new FileGetter();
			//create the graph from file
			navigator = new Navigator();
			navigator.loadMap(fileGetter.readFileFromClasspath());
		}
	}
	
	
	public ReturnValue travelRoute(Map<String, Object>params)
	{
		String startAddress = 	params.get("startAddress").toString();	
		String startLongitude = params.get("startLongitude").toString();
		String startLatitude = params.get("startLatitude").toString();
		String endAddress = params.get("endAddress").toString();
		String endLongitude = params.get("endLongitude").toString();
		String endLatitude = params.get("endLatitude").toString();
		String choose = params.get("choose").toString();

		Address startPoint = new Address(startAddress, startLongitude, startLatitude);
		Address endPoint = new Address(endAddress, endLongitude, endLatitude);

		List<Address> addresses;
		long time1;
		long time2;
		switch (choose)
		{
			case "1":
				//步行最少
				System.out.print("\n\n\n步行最少：\n查询时间(ns): ");
				time1 = System.nanoTime();
				addresses = navigator.getPath_OF_MINWALIKING(startPoint,endPoint);
				time2 = System.nanoTime();
				System.out.println(time2 - time1);
				break;
			case "2":
				//换乘最少
				System.out.print("\n\n\n换乘最少：\n查询时间(ns): ");
				time1 = System.nanoTime();
				addresses = navigator.getPath_OF_MINCHANGETIMES(startPoint,endPoint);
				time2 = System.nanoTime();
				System.out.println(time2 - time1);
				break;
			case "3":
				//时间最短:
				System.out.print("\n\n\n时间最短：\n查询时间(ns): ");
				time1 = System.nanoTime();
				addresses = navigator.getPath_OF_MINTIME(startPoint,endPoint);
				time2 = System.nanoTime();
				System.out.println(time2 - time1);
				break;
			default:
				time1 = System.nanoTime();
				addresses = navigator.getPath_OF_MINWALIKING(startPoint,endPoint);
				time2 = System.nanoTime();
				System.out.println(time2 - time1);
				break;
		}
		System.out.print("路线图：");
		System.out.print(startAddress + "-->");
		for(Address address:addresses)
			System.out.print(address.getAddress() + "-->");
		System.out.println(endAddress);
		System.out.println("全程需时：" + navigator.getMinutes() + " min");
		System.out.println("步行距离：" + navigator.getWalkDistance() + " m");
		ReturnValue returnValue=new ReturnValue();
		returnValue.setStartPoint(startPoint);
		returnValue.setEndPoint(endPoint);
		returnValue.setSubwayList(addresses);
		returnValue.setMinutes(navigator.getMinutes());
		returnValue.setWalkDistance(navigator.getWalkDistance());
		return returnValue;
	}
}
