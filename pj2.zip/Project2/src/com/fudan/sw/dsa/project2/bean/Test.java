package com.fudan.sw.dsa.project2.bean;

import com.fudan.sw.dsa.project2.constant.FileGetter;

import java.util.ArrayList;

public class Test {
    public static void main(String[] args){
        FileGetter fileGetter = new FileGetter();
        Navigator navigator = new Navigator();
        navigator.loadMap(fileGetter.readFileFromClasspath());
        Address address5 = new Address("莘庄","121.391768","31.116549");
        Address address6 = new Address("东方绿洲","121.026356","31.104151");
        ArrayList<Address> addresses3 = navigator.getPath_OF_MINCHANGETIMES(address5,address6);
        for(Address address:addresses3){
            System.out.print(address.getAddress() + "--");
        }
        System.out.println(navigator.getMinutes());
        System.out.println(navigator.getWalkDistance());
    }
}
