package com.fudan.sw.dsa.project2.bean;

import java.util.ArrayList;

class Vertex {
    private Address address;
    private ArrayList<Edge> edges = new ArrayList<>();
    private ArrayList<Vertex> vertices = new ArrayList<>();
    private double distance;
    private Vertex preVertex;
    private String toLines = ""; //到达当前站的线路
    ArrayList<Vertex> preVertices = new ArrayList<>();
    Vertex(String address,String longitude, String latitude){
        this.address = new Address(address,longitude,latitude);
    }
    Vertex(){}
    Vertex(Address address){
        this.address = address;
    }

    int getChangeTimes(){
        return address.getChangeTimes();
    }

    void setChangeTimes(int changeTimes){
        address.setChangeTimes(changeTimes);
    }

    void AddEdge(Vertex vertex1,String line,double weight){  //加入一边
        Edge edge = new Edge(this,vertex1,line,weight);
        edges.add(edge);
    }


    String getName(){
        return address.getAddress();
    }

    ArrayList<Edge> getEdges(){
        return edges;
    }

    void setDistance(double distance){
        this.distance = distance;
    }

    double getDistance(){
        return distance;
    }

    Edge getEdge(Vertex vertex1){
        for(int i = edges.size() - 1; i >= 0; i--){
            if(edges.get(i).getOtherVertex(this) == vertex1){
                return edges.get(i);
            }
        }
        return null;//一般不可到达，到达即为错误
    }

    void setPreVertex(Vertex vertex){ //设置前驱点
        this.preVertex = vertex;
    }

    Vertex getPreVertex(){  //获得前驱点
        return preVertex;
    }

    void addVertex(Vertex vertex){
        vertices.add(vertex);
    }

    ArrayList<Vertex> getVertices(){
        return vertices;
    }

    Address getAddress(){
        return address;
    }

    int getChangeOrNot(Vertex vertex){
        if(preVertices.contains(vertex)){
            return 10;//不走回头路
        }
        if(toLines.contains(this.getEdge(vertex).getLine())){
            return 0;
        }
        return 1;
    }

    void setToLines(String line,int type){
        if(type == 0){
            toLines = line;
        }else if(!toLines.contains(line)) {
            toLines += ":" + line;
        }
    }

    void setPreVertices(Vertex vertex,int type){
        if(type == 0){
            preVertices = new ArrayList<>();
            preVertices.add(vertex);
        }else if(!preVertices.contains(vertex)) {
            preVertices.add(vertex);
        }
    }

    int linesIndexof(String line){
        String[] lines = toLines.split(":");
        for(int i = 0; i < lines.length; i++){
            if(lines[i].equals(line)){
                return i;
            }
        }
        return 0;
    }

    Vertex getPreVertex(int index){
        return preVertices.get(index);
    }

    String getToLines(){
        return toLines;
    }

    void clearAll(){
        toLines = "";
        preVertices = new ArrayList<>();
    }
}
